function canvasApp(){
    let ctx = document.getElementById("canvas").getContext("2d");
    ctx.beginPath();
    ctx.arc(100, 100, 75, 0, Math.PI * 2, true);
    ctx.fillStyle = "yellow";
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(55,70);
    ctx.arc(65, 70, 10, 0, Math.PI * 2, true);
    ctx.moveTo(125, 70);
    ctx.arc(135, 70, 10, 0, Math.PI * 2, true);
    ctx.moveTo(134, 120);
    ctx.fillStyle = "black";
    ctx.lineWidth = 6;
    ctx.fill();
    ctx.arc(99, 120, 35, 0, Math.PI , false);
    ctx.stroke();
    ctx.font = "20px sans serif";
    ctx.fillText("Hello Canvas!", 45, 200);
}

function displayDayTime(){
    let date = new Date();
    dateOpt = {weekday : 'long', year: 'numeric', month : 'long', day :'numeric'};
    if(!document.getElementById("date")){
        let dayTime = document.createElement("p");
        dayTime.id = "date";
        dayTime.innerText = `Nous somme le ${date.toLocaleDateString("fr-FR", dateOpt)}
        Il est actuellement ${date.toString().split(" ")[4]}`;
        document.body.insertBefore(dayTime,document.getElementById("canvas"));
    }else{
        document.getElementById("date").innerText =  `Nous somme le ${date.toLocaleDateString("fr-FR", dateOpt)}
        Il est actuellement ${date.toString().split(" ")[4]}`;
    }
}

function displayDecrementSecond(){
    let cd = 58000;
    let timeOutStr = document.createElement("p");
    document.body.insertBefore(timeOutStr, document.getElementById("canvas"));
    let timerId = setInterval(()=>{
        if(cd <= 1){
            timeOutStr.innerText = "Le dessin est affiché ci-dessous";
            canvasApp();
            clearInterval(timerId);
        }else{
        cd -= 1000;
        timeOutStr.innerText = `Le dessin ci dessous va s'afficher après ${cd/1000} secondes`;
        }
    }, 1000);
}

function main(){
    displayDecrementSecond();
    setInterval(displayDayTime, 1000);
}

main();
